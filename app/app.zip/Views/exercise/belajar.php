<?= $this->extend('template/dashboard-belajar') ?>
<?= $this->section('content') ?>


<div class="row">
    <div class="col-xl-12">
        <div class="card">
            <!-- <div class="card-header">
                <h4 class="text-center">Pembelajaran tentang Tubuh Manusia</h4>
            </div> -->
            <div class="card-body">
                <!--
                <iframe src="`https://materi-pait.devinc.website/tubuh" width="100%" height="500px"></iframe>
                -->
                <iframe src="https://belajaryuk.devinc.website/kisi-kisi-demo/" width="100%" height="500px"></iframe>
            </div>
            <div class="card-footer">
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>